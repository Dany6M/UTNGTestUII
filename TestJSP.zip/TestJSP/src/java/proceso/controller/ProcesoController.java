/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proceso.controller;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import proceso.dao.ProcesoDAO;
import proceso.dao.ProcesoDAOimp;
import proceso.model.Proceso;

/**
 *
 * @author Daniel Aguilar
 */
public class ProcesoController extends HttpServlet {
    private static final String LISTA_PROCESO="/listarProcesos.jsp";
    private static final String AGREGAR_O_CAMBIAR="/procesos.jsp";
    private ProcesoDAO dao;
    public ProcesoController(){
       dao=new ProcesoDAOimp();
    }

   
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
          String forward="";
        String action =request.getParameter("action");
       if(action.equalsIgnoreCase("borrar")){
       forward=LISTA_PROCESO;
       int pid=Integer.parseInt(request.getParameter("pid"));
       dao.borrarProceso(pid);
       request.setAttribute("procesos", dao.desplegarProcesos());
       
       }else if(action.equalsIgnoreCase("cambiar")){
           forward=AGREGAR_O_CAMBIAR;
           
        int pid=Integer.parseInt(request.getParameter("pid"));
       Proceso proceso=dao.elejirProceso(pid);
       request.setAttribute("proceso", proceso);
       }else if(action.equalsIgnoreCase("agregar")){
           forward=AGREGAR_O_CAMBIAR;
       }else{
           forward=LISTA_PROCESO;
           request.setAttribute("procesos", dao.desplegarProcesos());
       }
             RequestDispatcher  view=request.getRequestDispatcher(forward);
             view.forward(request,response);    
       
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        Proceso proceso= new Proceso();
      String pid=request.getParameter("pid");
      proceso.setState(request.getParameter("state"));
      proceso.setType(request.getParameter("type"));
      proceso.setVersion(request.getParameter("version"));
      proceso.setDu(request.getParameter("du"));
      if(pid==null||pid.isEmpty()){
          dao.agregarProceso(proceso);
      }else{
          proceso.setPid(Integer.parseInt(pid));
          dao.cambiarProceso(proceso);
      }
      RequestDispatcher view= request.getRequestDispatcher(LISTA_PROCESO);
      request.setAttribute("procesos", dao.desplegarProcesos());
      view.forward(request, response);
    }

   
}
