/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proceso.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import proceso.model.Proceso;
import proceso.util.utilBD;

/**
 *
 * @author Daniel Aguilar
 */
public class ProcesoDAOimp implements ProcesoDAO{
     private Connection connection;
     public ProcesoDAOimp(){
        connection=utilBD.getConnection();
    }

    @Override
    public void agregarProceso(Proceso proceso) {
         try{
            String query="INSERT INTO procesos (PID, STATE, TYPE, VERSION, DU)"
                    +"VALUES(?,?,?,?,?)";
            PreparedStatement ps=connection.prepareStatement(query);
            ps.setInt(1, proceso.getPid());
            ps.setString(2, proceso.getState());
            ps.setString(3, proceso.getType());
            ps.setString(4, proceso.getVersion());
            ps.setString(5, proceso.getDu());
            
            ps.executeUpdate();
            ps.close();
        }catch(SQLException e){
            e.printStackTrace();
        }
    }

    @Override
    public void borrarProceso(int pid) {
          try{
           String query="DELETE FROM procesos WHERE PID= ?";
           PreparedStatement ps = connection.prepareCall(query);
           ps.setInt(1, pid);
           ps.executeUpdate();
       }catch(SQLException e){
           e.printStackTrace();
       }
    }

    @Override
    public void cambiarProceso(Proceso proceso) {
         try{
            String query= "UPDATE procesos SET PID= ? ,STATE= ?,TYPE= ?,VERSION= ?,DU= ? WHERE PID= ?";
            PreparedStatement ps=connection.prepareCall(query);
            ps.setInt(1, proceso.getPid());
            ps.setString(2, proceso.getState());
            ps.setString(3, proceso.getType());
            ps.setString(4, proceso.getVersion());
            ps.setString(5, proceso.getDu());
            ps.executeUpdate();
            ps.close();
        }catch(SQLException e){
            e.printStackTrace();
        }
    }

    @Override
    public List<Proceso> desplegarProcesos() {
        List<Proceso> procesos = new ArrayList<Proceso>();
        try{
              Statement statement=connection.createStatement();
              ResultSet rs=  statement.executeQuery("SELECT * FROM usuarios");
              while(rs.next()){
                  Proceso proceso= new Proceso(rs.getInt("PID"),rs.getString("STATE"),rs.getString("TYPE"),
                          rs.getString("VERSION"),rs.getString("DU"));
                  procesos.add(proceso);
              }
              rs.close();
              statement.close();
        }catch(SQLException e){
            e.printStackTrace();
        }
        
        
      return procesos;
    }

    @Override
    public Proceso elejirProceso(int pid) {
        Proceso proceso = null;
            try{
            String query="SELECT * FROM procesos WHERE PID= ?";;
              PreparedStatement statement=connection.prepareStatement(query);
              statement.setInt(1, pid);
              ResultSet rs=  statement.executeQuery();
             if(rs.next()){
                   proceso= new Proceso(rs.getInt("PID"),rs.getString("STATE"),rs.getString("TYPE"),
                          rs.getString("VERSION"),rs.getString("DU"));
                  
              }
              rs.close();
             statement.close();
        }catch(SQLException e){
            e.printStackTrace();
        }
        
        
        return proceso;
    }
        
}//fin clase
