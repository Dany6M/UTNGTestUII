/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proceso.dao;

import java.util.List;
import proceso.model.Proceso;

/**
 *
 * @author Daniel Aguilar
 */
public interface ProcesoDAO {
    void agregarProceso(Proceso proceso);
    void borrarProceso(int pid);
    void cambiarProceso(Proceso proceso);
    List<Proceso>desplegarProcesos();
    Proceso elejirProceso(int pid);
}
